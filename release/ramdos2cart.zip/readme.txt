RAMDOS II 1-2 MB Cartridge for UII+ (or VICE)
Original RAMDOS written by Commodore
2MB REU Patch by Andrew Mileski
16MB Patch By Scott Hutter
Cartridge compiled by Scott Hutter

This is an 8k cartridge binary that you can use to utilize your REU (up to 16MB) as a ramdrive.

To use:  

1) Select the ramdos2.bin file from the U2 or U2+ menus.  
2) Select "Use as Catridge ROM".
   A message will appear telling you to now select the appropriate Custom Cart.
3) Press F2.  Go to "Cartridge" and select "Custom 8k ROM"
4) Hit Run/Stop to return to the previous menu
5) Hard reset the 64 - it will force the cart to load after next startup

You should then be welcomed with the normal 64 screen, but with drive 15 as your new ramdrive.

Note,because it uses a RAM check routine, the larger your REU, the longer it will take to start.
A 16MB Ramdisk will take about 3 seconds to be ready.

Enjoy.