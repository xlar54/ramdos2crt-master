RAMDOS II 1-2 MB Cartridge for UII+ (or VICE)
Original RAMDOS written by Commodore
2MB REU Patch by Andrew Mileski
Cartridge compiled by Scott Hutter

This is an 8k cartridge binary that you can use to utilize your REU (up to 2MB) as a ramdrive.

To use:  Select the ramdos2.bin file from the U2 or U2+ menus.  Select "Use as Catridge ROM".
A message will appear telling you to now select the appropriate Custom Cart.
Press F2.  Go to "Cartridge" and select "Custom 8k ROM"
Hit Run/Stop to return to the previous menu
Press F5, then Restart C64

You should then be welcomed with the normal 64 screen, but with drive 15 as your new ramdrive.

Enjoy.